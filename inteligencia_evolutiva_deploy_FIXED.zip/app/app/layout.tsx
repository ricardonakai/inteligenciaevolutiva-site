
import type { Metadata } from 'next'
import { Inter, Merriweather } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from '@/components/ui/toaster'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const merriweather = Merriweather({ 
  weight: ['300', '400', '700', '900'],
  subsets: ['latin'], 
  variable: '--font-merriweather' 
})

export const metadata: Metadata = {
  title: 'Inteligência Evolutiva | Ricardo Nakai',
  description: 'Descubra a Inteligência Evolutiva e o Método AWAKE. Uma nova forma de evoluir conscientemente através da transformação pessoal e comportamental.',
  keywords: 'inteligência evolutiva, método awake, ricardo nakai, transformação pessoal, comportamento humano, desenvolvimento pessoal',
  authors: [{ name: 'Ricardo Nakai' }],
  openGraph: {
    title: 'Inteligência Evolutiva | Ricardo Nakai',
    description: 'Uma nova inteligência que nasce da travessia entre sobrevivência e essência.',
    type: 'website',
    locale: 'pt_BR',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${merriweather.variable}`}>
      <body className="font-sans antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
