
import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { z } from 'zod'

const prisma = new PrismaClient()

const contatoSchema = z.object({
  nome: z.string().min(1, 'Nome é obrigatório'),
  email: z.string().email('E-mail inválido'),
  mensagem: z.string().min(10, 'Mensagem deve ter pelo menos 10 caracteres'),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate the request body
    const validatedData = contatoSchema.parse(body)
    
    // Save to database
    const contato = await prisma.contato.create({
      data: {
        nome: validatedData.nome,
        email: validatedData.email,
        mensagem: validatedData.mensagem,
        createdAt: new Date(),
      },
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Contato salvo com sucesso',
      id: contato.id 
    })
  } catch (error) {
    console.error('Erro ao salvar contato:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, message: 'Dados inválidos', errors: error.errors },
        { status: 400 }
      )
    }
    
    return NextResponse.json(
      { success: false, message: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
